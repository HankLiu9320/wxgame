# brick-breaker-master
Cocos Creator 1.5 打砖块
教程地址：http://blog.csdn.net/potato47/article/details/73197021
